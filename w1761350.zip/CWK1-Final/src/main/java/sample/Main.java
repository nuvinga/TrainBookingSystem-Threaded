package sample;

import com.mongodb.client.*;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import org.bson.Document;

import java.time.LocalDate;
import java.util.*;

public class Main extends Application {

    static final int SEATING_CAPACITY = 42;
    private static ToggleButton[] button = new ToggleButton[SEATING_CAPACITY + 1];
    private static ArrayList<String> seatList = new ArrayList<>();
    private static String[] cache =new String[6];
    private static int uniqueId = 1000;
    private static String[] stops={"Colombo-Fort","Polgahawela","Peradeniya","Gampola","Nawalapitiya","Hatton",
            "Thalawakele","Nanuoya","Haputale","Diyatalawa","Bandarawela","Ella","Badulla"};

    //================================================== METHODS =====================================================//

    public static void main(String[] args) { launch(args); }

    public void start(Stage primaryStage) throws Exception {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to the Denuwara Menike train Seat Booking System!");
        System.out.println(" ");
        System.out.println("We encourage downloading essential real-time data from our database. Press <L> to download or " +
                "any other key to continue without downloading.");
        String choice= input.next().toLowerCase();
        if (choice.equals("l")) {
            System.out.println("Downloading Data Files..");
            databaseRetrieval();  // Calling
        }else{
            System.out.println(" ");
            System.out.println("Okay! Let's get Started!");
            menu();
        }
    }

    // ================================================= MAIN MENU ================================================== //
    public void menu() throws Exception {
        Scanner input = new Scanner(System.in);
        String option;
        System.out.println(" ");
        System.out.println("==================================MAIN MENU===================================");
        System.out.println(" ");
        System.out.println("   A: Add Customer to Seat");
        System.out.println("   V: View all Seats");
        System.out.println("   E: Display Empty seats");
        System.out.println("   D: Delete customer from seat");
        System.out.println("   F: Find seats of a Customer");
        System.out.println("   S: Store data to file");
        System.out.println("   L: Load data from file");
        System.out.println("   O: View Seats ordered");
        System.out.println("   Q: Exit Program");
        System.out.println(" ");
        System.out.print("Enter your option here: ");
        option = input.next();  // receives input from user
        option = option.toUpperCase();
        switch (option) {
            case "A":
                gui("addCustomers");  //call add customers and evokes GUI
                break;
            case "V":
                gui("viewSeats");  //call view all seats and evokes GUI
                break;
            case "E":
                gui("viewEmpty");  //call empty seats and evokes GUI
                break;
            case "D":
                System.out.println(" ");
                System.out.println("===============================DELETE YOUR SEAT===============================");
                System.out.println(" ");
                System.out.println("Let's delete your seat. Please enter the following information.");
                deleteCustomer();  //call delete customer data
                break;
            case "F":
                System.out.println(" ");
                System.out.println("================================FIND YOUR SEAT================================");
                System.out.println(" ");
                System.out.println("Let's find your seat. Please fill in the following information.");
                findCustomer();   //call find customer
            case "S":
                System.out.println(" ");
                System.out.println("=================================UPLOAD DATA==================================");
                System.out.println(" ");
                databaseStore();  //call store data
                break;
            case "L":
                System.out.println(" ");
                System.out.println("================================DOWNLOAD DATA=================================");
                System.out.println(" ");
                databaseRetrieval();  //call load data
                break;
            case "O":
                System.out.println(" ");
                System.out.println("=================================SORT SEATS===================================");
                System.out.println(" ");
                sortSeats();  //call view seats order
                break;
            case "Q":
                System.out.println("====================================WARNING===================================");
                // Convinces the user to store the data first into the database since otherwise data will be lost
                System.out.println("Hold up! Did you upload your seat bookings back to the database using function 'S'?" +
                        "If you haven't please do so, or your seat won't be Saved! Even if you deleted one, it will still be available!");
                System.out.println(" ");
                System.out.println("Press <B> to move back to the menu, or press any other key to quit ");
                String choice= input.next().toLowerCase();  // getting users confirmation for exit
                if (choice.equals("b")){ // if user chose to stay in program
                    menu();
                }else {  //if user chose to exit program
                    System.out.println("Thank you using Denuwara Manike Online Seat Booking system. Please be on time " +
                            "for your train. Have a good day and a Safe Journey!");
                    System.exit(1);
                }
            default:
                System.out.println("Oops! We couldn't read that. Please check the options again and re-enter.");
                menu();
        }
    }

    //=================================================== MAIN GUI ================================================== //
    public void gui(String method) {

        //Common GUI to all three cases

        //==============================================================================================================
        //                                  Initializing all elements

        //======================================================================================================= Stages
        //============================= First stage
        Stage firstStage = new Stage();
        BorderPane firstRoot = new BorderPane();  // creating a root for stage
        Scene firstScene = new Scene(firstRoot, 1000, 350);
        firstRoot.getStylesheets().add("/style.css");  // calling a style sheet to allow css
        firstRoot.setId("imageOne");
        firstStage.setScene(firstScene);
        firstStage.setTitle("Book Seats");
        firstStage.setResizable(false);  // Amending stage decoration- Disabling resizing
        firstStage.setFullScreen(false);  // Amending stage decoration- Disabling full screen movement
        firstStage.setOnCloseRequest(event -> {  // Amending stage decoration- Close request to call back menu
            firstStage.close();
            try {
                menu();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        //============================= Second stage
        Stage secondStage = new Stage();
        BorderPane secondRoot = new BorderPane();  // creating a root for stage
        Scene secondScene = new Scene(secondRoot, 500, 650);
        secondRoot.getStylesheets().add("/style.css");  // calling a style sheet to allow css
        secondRoot.setId("imageTwo");
        secondStage.setScene(secondScene);
        secondStage.setTitle("Book Seats");
        secondStage.setResizable(false);  // Amending stage decoration- Disabling resizing
        secondStage.setFullScreen(false);  // Amending stage decoration- Disabling full screen movement
        secondStage.setOnCloseRequest(event -> {  // Amending stage decoration- Close request to call back menu
            secondStage.close();
            try {
                menu();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        //======================================================================================================= Labels
        Label mainLabel = new Label("Denuwara Manike Train Seat Booking System");
        mainLabel.setFont(Font.font("sans-serif", FontWeight.BOLD, FontPosture.REGULAR, 30));
        mainLabel.setPadding(new Insets(20,20,5,20));

        Label subLabel = new Label("Fill in the following forms to find your Train");
        subLabel.setFont(Font.font("sans-serif", 18));
        subLabel.setPadding(new Insets(10, 10, 10, 10));

        Label seatsAddLabel = new Label("Please select seats");
        seatsAddLabel.setFont(Font.font("sans-serif", 18));
        seatsAddLabel.setPadding(new Insets(10));

        Label dateLabel = new Label("Select date: ");
        dateLabel.setPadding(new Insets(0, 10, 0, 10));

        Label directionLabel = new Label("Choose Direction: ");
        directionLabel.setPadding(new Insets(0, 10, 0, 50));

        Label startStation = new Label("Start Station: ");
        startStation.setPadding(new Insets(0, 10, 0, 10));

        Label endStation = new Label("Destination Station: ");
        endStation.setPadding(new Insets(0, 10, 0, 50));

        Label availableLabel = new Label("Available Seats");

        Label usedLabel = new Label("Occupied Seats");


        //====================================================================================================== Buttons
        Button bookSeats = new Button("Select Seats");
        bookSeats.setPadding(new Insets(20, 70, 20, 70));

        Button bookButton = new Button("Book Seats");
        bookButton.setId("addCustomersBookButton");

        Button clearSeats = new Button("Clear Seats");
        clearSeats.setId("addCustomersClearSeats");

        Button exit = new Button("Exit");
        exit.setId("addCustomersExit");

        Button clearDir = new Button("Clear Selections");
        clearDir.setPadding(new Insets(20, 70, 20, 70));

        Button mainExit = new Button("Exit ");
        mainExit.setPadding(new Insets(20, 70, 20, 70));

        Button available = new Button();

        Button used = new Button();


        //================================================================================================== Combo boxes
        ComboBox directionList = new ComboBox();
        directionList.getItems().addAll(
                "Colombo to Badulla", "Badulla to Colombo"
        );

        ComboBox ctbStops = new ComboBox();
        ctbStops.setId("combo");

        ComboBox btcStops = new ComboBox();
        btcStops.setId("combo");

        //================================================================================================== Date Picker
        DatePicker dateSelector = new DatePicker();
        dateSelector.setPromptText("Date");


        //================================================================================================== Alert Boxes
        Alert confirmExitAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmExitAlert.setTitle("Exit Waring ");
        confirmExitAlert.setHeaderText("Are you sure you want to exit?");
        confirmExitAlert.setContentText("You will move back to the main menu!");


        //==============================================================================================================
        //                          First Stage   -   Stations and Date Selector Menu

        firstStage.show();  // first stage will be shown

        VBox menu = new VBox(25);  //Main Box
        VBox menuLabels = new VBox();  //Box for Labels
        HBox dateAndDirectionStretch = new HBox();  //Box for date and Direction Selector
        HBox stationStretch = new HBox();  //Box for stations selector
        HBox bookButtonStretch = new HBox(25);  // Box for book Button
        menu.setAlignment(Pos.CENTER);  // All the boxes will be aligned Center for visual effects
        menuLabels.setAlignment(Pos.CENTER);
        dateAndDirectionStretch.setAlignment(Pos.CENTER);
        bookButtonStretch.setAlignment(Pos.CENTER);
        stationStretch.setAlignment(Pos.CENTER);
        firstRoot.setCenter(menu);
        menu.setPrefHeight(300);  // Utilizes the whole spacing
        menu.getChildren().add(menuLabels);  // All the sub-boxes will be called as children in the main box
        menu.getChildren().add(dateAndDirectionStretch);
        menu.getChildren().add(stationStretch);
        menu.getChildren().add(bookButtonStretch);
        menuLabels.getChildren().add(mainLabel);  // Accessing children
        menuLabels.getChildren().add(subLabel);
        dateAndDirectionStretch.getChildren().add(dateLabel);  // Accessing children
        dateAndDirectionStretch.getChildren().add(dateSelector);
        dateAndDirectionStretch.getChildren().add(directionLabel);
        dateAndDirectionStretch.getChildren().add(directionList);
        directionList.valueProperty().addListener((observable, oldValue, newValue) -> {
            //on selection of a value from the first combo box, selecting direction
            if (newValue == "Colombo to Badulla") {
                directionList.setDisable(true);  //list wont be updatable after selection
                ctbStops.setDisable(false);  //comboBox will be enabled for selection
                dateSelector.setDisable(true);  //date selector will be disabled
                cache[1] = "ctb";  //Storing user Selection history for system use
                stationStretch.getChildren().add(startStation);  //expanding gui with station selectors
                stationStretch.getChildren().add(ctbStops);
                stationStretch.getChildren().add(endStation);
                stationStretch.getChildren().add(btcStops);
                btcStops.setDisable(true);  //disabling so that user selects the start station first
                ctbStops.getItems().clear();  //clearing the data from past activity
                for (int i=0;i<12;i++){
                    ctbStops.getItems().add(stops[i]);  // populating comboBox using array- stops
                }
                ctbStops.valueProperty().addListener(((observable1, oldValue1, newValue1) -> {
                    //on selection of a start station
                    btcStops.setDisable(false);  //enabling destination comboBox
                    ctbStops.setDisable(true);  //disabling so it cannot be changed
                    int selection=0;
                    for (int i=0;i<12;i++){
                        String finalI= String.valueOf(i);
                        if (stops[i].contains(newValue1.toString())){  //traversing array to get selected value index
                            selection=i;  //storing index of value selected
                            if (i<10){  // if number is a single digit, a zero added in front
                                cache[3]="0"+finalI;  //Storing user Selection history for system use
                            }else{
                                cache[3]=finalI;
                            }
                        }
                    }
                    for (int i=12;i>selection;i--){  //populating second comboBox according to selection in last comboBox
                        btcStops.getItems().add(stops[i]);
                    }
                    btcStops.valueProperty().addListener((observable2,oldValue2,newValue2) -> {
                        //on selection in the second comboBox
                        int selection1= Integer.parseInt(cache[3]);
                        for (int i=12;i>selection1;i--){
                            String finalI= String.valueOf(i);
                            if (stops[i].contains(newValue2.toString())){  //traversing array to get selected value index
                                if (i<10){  // if number is a single digit, a zero added in front
                                    cache[4]="0"+finalI;  //Storing user Selection history for system use
                                }else{
                                    cache[4]=finalI;
                                }
                            }
                        }
                        cache[5]= cache[3]+"t"+ cache[4];
                        bookSeats.setDisable(false);  // Allowing user to select select seats button
                        cache[2]="#"+ cache[1]+"#"+ cache[5]+"#"+ cache[0]+"#"; //Storing user Selection history for system use,
                        switch (method) {  //validating method input from system to call appropriate function
                            case "addCustomers":
                                addCustomers(secondStage, bookButton, clearSeats, exit, used, available);//call add customers
                                break;
                            case "viewSeats":
                                viewSeats(secondStage, exit, used, available);//call the view seats procedure
                                break;
                            case "viewEmpty":
                                emptySeats(secondStage, exit, used, available); // call the empty seats procedure
                                break;
                        }
                    });
                }));
            } else if (newValue == "Badulla to Colombo"){ // if the user selected btc
                directionList.setDisable(true);  //so that direction cannot be changed again
                dateSelector.setDisable(true);
                btcStops.setDisable(false);
                cache[1] = "btc"; //Storing user Selection history
                stationStretch.getChildren().add(startStation); // adding the dropdowns and disabling unusefulls
                stationStretch.getChildren().add(btcStops);
                stationStretch.getChildren().add(endStation);
                stationStretch.getChildren().add(ctbStops);
                ctbStops.setDisable(true);
                btcStops.getItems().clear();
                for (int i=12;i>0;i--){
                    btcStops.getItems().add(stops[i]);  //populating combobox through list
                }
                btcStops.valueProperty().addListener(((observable1, oldValue1, newValue1) -> {  //first list selection
                    ctbStops.setDisable(false);
                    btcStops.setDisable(true);
                    int selection=0;
                    for (int i=12;i>0;i--){
                        String finalI= String.valueOf(i);
                        if (newValue1.equals(stops[i])){
                            if (i<10){
                                selection=i;
                                cache[3]="0"+finalI;
                            }else{
                                selection=i;
                                cache[3]=finalI;
                            }
                        }
                    }
                    for (int i=0;i<selection;i++){
                        ctbStops.getItems().add(stops[i]);  //populating second list inregard to the selection in list one
                    }
                    ctbStops.valueProperty().addListener((observable2,oldValue2,newValue2) -> {
                        int selection1= Integer.parseInt(cache[3]);
                        for (int i=0;i<selection1;i++){
                            String finalI= String.valueOf(i);
                            if (newValue2.equals(stops[i])){
                                if (i<10){
                                    cache[4]="0"+finalI;
                                }else{
                                    cache[4]=finalI;
                                }
                            }
                        }
                        cache[5]= cache[3]+"t"+ cache[4];
                        bookSeats.setDisable(false);
                        cache[2]="#"+ cache[1]+"#"+ cache[5]+"#"+ cache[0]+"#"; //Storing user Selection history
                        switch (method) {
                            case "addCustomers":
                                addCustomers(secondStage, bookButton, clearSeats, exit, used, available);//call add customers
                                break;
                            case "viewSeats":
                                viewSeats(secondStage, exit, used, available);//call the view seats procedure
                                break;
                            case "viewEmpty":
                                emptySeats(secondStage, exit, used, available); // call the empty seats procedure
                                break;
                        }
                    });
                }));
            }
            stationStretch.setDisable(false); //Allowing the user to access seats selection
        });
        bookButtonStretch.getChildren().add(mainExit);  //exit button which allows user to go back to menu
        bookButtonStretch.getChildren().add(bookSeats); //sleect button which allows user to move to second giu
        bookButtonStretch.getChildren().add(clearDir); //clear button which allows user to clear his selections which were disabled
        bookSeats.setDisable(true);
        dateSelector.setOnAction(event ->         // Storing date information
                cache[0]=dateSelector.getValue().toString()
        );
        dateSelector.setDayCellFactory(picker -> new DateCell() { //Disabling previous dates in date picker
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                LocalDate today = LocalDate.now();
                setDisable(empty || date.compareTo(today) < 0);
            }
        });
        mainExit.setOnAction(event -> {  //on click exit button
            Optional<ButtonType> result = confirmExitAlert.showAndWait();
            if (result.get() == ButtonType.OK) {
                firstStage.close();
                try {
                    menu(); //calling back menu to sustain program- On  press ofexit button
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        bookSeats.setOnAction(event -> { //Calling the new stage while closing the old
            firstStage.close();
            secondStage.show();
        });
        clearDir.setOnAction(event -> {  //onclick of the clear button
            firstStage.close();
            gui(method);  //inorder to clear disabled buttons
        });


        //    Second Stage  -   Seat Selection and Show

        //Header Box- The Heading and Name label
        VBox secondLabelStretch=new VBox(); //Creating boxes
        VBox colors = new VBox();
        HBox usedSeatsStretch = new HBox();
        HBox freeSeatsStretch = new HBox();
        secondLabelStretch.getChildren().add(seatsAddLabel); //Adding its inheritance for children
        secondRoot.setTop(secondLabelStretch);
        secondLabelStretch.getChildren().add(colors);
        colors.getChildren().add(usedSeatsStretch);
        colors.getChildren().add(freeSeatsStretch);
        usedSeatsStretch.getChildren().add(used);
        usedSeatsStretch.getChildren().add(usedLabel);
        freeSeatsStretch.getChildren().add(available);
        freeSeatsStretch.getChildren().add(availableLabel);


        //Left- seat buttons set 1
        FlowPane left = new FlowPane(Orientation.HORIZONTAL, 15, 15); //Creating the pane for the seats
        left.setPadding(new Insets(10, 10, 10, 20));
        left.setPrefWrapLength(180);
        int count;
        for (count = 1; count <= 21; count++) {  // creating first set of buttons using counters
            button[count] = new ToggleButton(String.valueOf(count));
            button[count].setId("toggleButton");
            button[count].setStyle("-fx-background-color: #cccbcc");
            left.getChildren().add(button[count]);
            secondRoot.setLeft(left);
        }


        //Right- seat buttons set 2
        FlowPane right = new FlowPane(Orientation.HORIZONTAL, 15, 15); //Creating the pane for the seats
        right.setPadding(new Insets(10, 20, 10, 10));
        right.setPrefWrapLength(180);
        for (count = 22; count <= SEATING_CAPACITY; count++) { // creating first set of buttons using counters
            button[count] = new ToggleButton(String.valueOf(count));
            button[count].setId("toggleButton");
            button[count].setStyle("-fx-background-color: #cccbcc");
            right.getChildren().add(button[count]);
            secondRoot.setRight(right);
        }


        //Footer box- The book and clear buttons
        HBox footer = new HBox();  //Creating the pane for the seats
        footer.setAlignment(Pos.CENTER);
        secondRoot.setBottom(footer);
        footer.setPrefHeight(100);
        footer.setSpacing(10);
        if ((method.equals("viewEmpty"))||(method.equals("viewSeats"))) {  // Calling the appropriate function to perform
            footer.getChildren().add(exit);
        }else {
            footer.getChildren().add(bookButton);
            footer.getChildren().add(clearSeats);
            footer.getChildren().add(exit);
        }
    }

    // ======================================= METHOD FOR ADD CUSTOMERS ie. "A" ===================================== //
    public void addCustomers(Stage secondStage, Button bookButton,Button clearSeats,Button exit,Button used,Button available) {

        //==============================================================================================================
        //                              Initializing all elements

        //-------------------------------------------------------------------------------------------------- Alert Boxes
        Alert noButtonsSelectedAlert = new Alert(Alert.AlertType.WARNING);
        noButtonsSelectedAlert.setTitle("Warning-No seats to book");
        noButtonsSelectedAlert.setHeaderText("No Seats Selected");
        noButtonsSelectedAlert.setContentText("You haven't selected any seats.");

        Alert confirmBookSeatsAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmBookSeatsAlert.setTitle("Confirmation for Booking");
        confirmBookSeatsAlert.setHeaderText("Are you sure to book the seats?");
        confirmBookSeatsAlert.setContentText("All the seats you've selected will be permanent");

        Alert confirmClearSeatsAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmClearSeatsAlert.setTitle("Clear seats");
        confirmClearSeatsAlert.setHeaderText("Are you sure to Clear seats?");
        confirmClearSeatsAlert.setContentText("All the seats you've selected will be cleared");

        Alert confirmExitAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmExitAlert.setTitle("Exit Form");
        confirmExitAlert.setHeaderText("Are you sure you want to exit?");
        confirmExitAlert.setContentText("All you'r work in progress will not be booked");

        Alert noName = new Alert(Alert.AlertType.WARNING);
        noName.setTitle("Warning!");
        noName.setHeaderText("No Name Entered");
        noName.setContentText("Please enter your name to continue");

        TextInputDialog getFirstName = new TextInputDialog();
        getFirstName.setTitle("Name Input");
        getFirstName.setHeaderText("Enter your FIRST NAME here");
        getFirstName.getDialogPane().lookupButton(ButtonType.CANCEL).setDisable(true);

        TextInputDialog getSurname = new TextInputDialog();
        getSurname.setTitle("Name Input");
        getSurname.setHeaderText("Enter your SURNAME here");
        getSurname.getDialogPane().lookupButton(ButtonType.CANCEL).setDisable(true);

        Alert seatId = new Alert(Alert.AlertType.INFORMATION);
        seatId.setTitle("Passenger ID");
        seatId.setHeaderText("Please remember this ID. This will be your Online Confirmation ID");

        //==============================================================================================================
        //                              Button Actions

        used.setStyle("-fx-background-color: #b24146"); // Guide colors styling
        used.setDisable(true);
        available.setStyle("-fx-background-color: #2fb2ae");

        ArrayList<Integer> temp = new ArrayList<>();
        for (int i=1;i<=SEATING_CAPACITY;i++){   // Adding button css through external style sheet
            button[i].setId("addSeatsButtons");
            button[i].setStyle("-fx-background-color: #2fb2ae");  //coloring unused buttons
        }

        //Initializing used buttons
        for (String s : seatList) {  //setting each item in seatlist array list to variable S
            // Styling and working for seats already booked
            String direction = cache[2].substring(1, 4);
            String seatNum = s.substring(0, 2);
            int start = Integer.parseInt(cache[2].substring(5, 7));  //getting values for checking values in array
            int end = Integer.parseInt(cache[2].substring(8, 10));
            int receivedStart = Integer.parseInt(s.substring(7, 9));
            int receivedEnd = Integer.parseInt(s.substring(10, 12));
            if (direction.compareTo("ctb") == 0) {  //checking inputs direction
                if ((s.contains(cache[0]))) {
                    if (!(((start <= receivedStart) && (end <= receivedStart)) || ((start >= receivedEnd) && (end >= receivedEnd)))) {
                        // validation of stops through array list id
                        button[Integer.parseInt(seatNum)].setStyle("-fx-background-color: #b24146");
                        button[Integer.parseInt(seatNum)].setDisable(true);
                    }
                }
            } else if (direction.compareTo("btc") == 0) {  //checking inputs direction
                if ((s.contains(cache[0]))) {
                    if (!(((start >= receivedStart) && (end >= receivedStart)) || ((start <= receivedEnd) && (end <= receivedEnd)))) {
                        // validation of stops through array list id
                        button[Integer.parseInt(seatNum)].setStyle("-fx-background-color: #b24146");
                        button[Integer.parseInt(seatNum)].setDisable(true);
                    }
                }
            }
        }

        //---------------------------------------------------------------------------------------- Seat buttons -OnClick
        for (int i = 1; i <= 42; i++) {
            int finalI = i;
            button[i].setOnAction(event -> {
                button[finalI].setStyle("-fx-background-color: #0db223"); // color will be changed
                temp.add(finalI);  //each element selected will be added to a new array list
                button[finalI].setDisable(true);  //will be disabled
            });
        }

        //----------------------------------------------------------------------------------------- Book button -OnClick
        bookButton.setOnAction(event -> {
            if (temp.isEmpty()) {
                noButtonsSelectedAlert.showAndWait();  //if no buttons selected Alert box shown
            } else {
                Optional<ButtonType> result = confirmBookSeatsAlert.showAndWait();  // Confirming selection
                if (result.get() == ButtonType.OK) {
                    secondStage.close();  // if ok- stage will be closed
                    for (int i = 0; i < temp.size(); i++) {
                        Optional<String> firstName;
                        Optional<String> surname;
                        int seatNum = temp.get(i);  // each item in array list with selected buttons will be put ro seatNum
                        do {
                            getFirstName.setContentText("Seat Number "+seatNum+": ");  //setting context to alertbox
                            getFirstName.getEditor().clear();  // Clearing any data from previous show
                            firstName = getFirstName.showAndWait(); //Getting name
                            if (firstName.get().equals("")) {
                                noName.showAndWait();// shows alert box to notify no name
                            }
                        } while (firstName.get().equals(""));  // will keep showing till name is entered
                        do {
                            getSurname.setContentText("Seat Number "+seatNum+": ");  //setting context to alertbox
                            getSurname.getEditor().clear();  // Clearing any data from previous show
                            surname = getSurname.showAndWait(); //Getting name
                            if (surname.get().equals("")) {
                                getSurname.showAndWait();// shows alert box to notify no name
                            }
                        } while (surname.get().equals(""));
                        int index = temp.get(i);
                        uniqueId += 1;  // getting id from global variable
                        seatId.setContentText("OCID for Seat Number " + seatNum + ": " + uniqueId);
                        seatId.showAndWait(); // presenting the OCID through another alert box
                        if (index<10){
                            seatList.add("0"+index+ cache[2]+firstName.get().toLowerCase()+" "+surname.get().toLowerCase()+
                                    "#"+uniqueId); //Storing history of the user selections
                        }else{
                            seatList.add(index+ cache[2]+firstName.get().toLowerCase()+" "+surname.get().toLowerCase()+
                                    "#"+uniqueId); //Storing history of the user selections
                        }
                    }
                    try {
                        menu(); //calling back menu to sustain program- On press of book button
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        //---------------------------------------------------------------------------------------- Clear button -OnClick
        clearSeats.setOnAction(event -> {
            if (temp.isEmpty()) {
                noButtonsSelectedAlert.showAndWait(); // Confirm if the user wants to delete seats
            } else {
                Optional<ButtonType> result = confirmClearSeatsAlert.showAndWait();
                if (result.get() == ButtonType.OK) {
                    for (int tempVal : temp) { // setting all selected seats to unselected again
                        button[tempVal].setDisable(false);
                        button[tempVal].setStyle("-fx-background-color: #2fb2ae");
                    }
                    temp.removeAll(temp); // clearing array list holding data of selected seats
                }
            }
        });

        //Exit button onClick
        exit.setOnAction(event -> {
            Optional<ButtonType> result = confirmExitAlert.showAndWait();  // confirm exit request
            if (result.get() == ButtonType.OK) {
                secondStage.close();  //stage will be closed
                try {
                    menu(); //calling back menu to sustain program- On  press ofexit button
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    // ====================================== METHOD FOR VIEW CUSTOMERS ie. "V" ===================================== //
    public void viewSeats(Stage seatSelection,Button exit,Button used,Button available) {

        //==============================================================================================================
        //                              Initializing all elements

        //-------------------------------------------------------------------------------------Alert boxes on validation
        Alert confirmExit = new Alert(Alert.AlertType.CONFIRMATION);
        confirmExit.setTitle("Exit Form");
        confirmExit.setHeaderText("Are you sure you want to exit?");
        confirmExit.setContentText("You will go back to the main menu.");

        //==============================================================================================================
        //                           Button Actions and initialization

        for (int i=1;i<=SEATING_CAPACITY;i++){
            button[i].setId("viewSeatsButtons");
            button[i].setStyle("-fx-background-color: #4fcc37"); // having an initial color for the buttons
        }

        used.setStyle("-fx-background-color: #b24146"); // Styling guide links
        used.setDisable(true);
        available.setStyle("-fx-background-color: #4fcc37");
        available.setDisable(true);

        //Initializing used buttons
        for (String s : seatList) {  //setting each item in seatlist array list to variable S
            // Styling and working for seats already booked
            String direction = cache[2].substring(1, 4);
            String seatNum = s.substring(0, 2);
            int start = Integer.parseInt(cache[2].substring(5, 7));  //getting values for checking values in array
            int end = Integer.parseInt(cache[2].substring(8, 10));
            int receivedStart = Integer.parseInt(s.substring(7, 9));
            int receivedEnd = Integer.parseInt(s.substring(10, 12));
            if (direction.compareTo("ctb") == 0) {  //checking inputs direction
                if ((s.contains(cache[0]))) {
                    if (!(((start <= receivedStart) && (end <= receivedStart)) || ((start >= receivedEnd) && (end >= receivedEnd)))) {
                        // validation of stops through array list id
                        button[Integer.parseInt(seatNum)].setStyle("-fx-background-color: #b24146");
                        button[Integer.parseInt(seatNum)].setDisable(true);
                    }
                }
            } else if (direction.compareTo("btc") == 0) {  //checking inputs direction
                if ((s.contains(cache[0]))) {
                    if (!(((start >= receivedStart) && (end >= receivedStart)) || ((start <= receivedEnd) && (end <= receivedEnd)))) {
                        // validation of stops through array list id
                        button[Integer.parseInt(seatNum)].setStyle("-fx-background-color: #b24146");
                        button[Integer.parseInt(seatNum)].setDisable(true);
                    }
                }
            }
        }

        //Exit button onClick
        exit.setOnAction(event -> {
            Optional<ButtonType> result = confirmExit.showAndWait();  // confirm exit request
            if (result.get() == ButtonType.OK) {
                seatSelection.close();  //stage will be closed
                try {
                    menu(); //calling back menu to sustain program- On  press ofexit button
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    // ===================================== METHOD FOR SHOW EMPTY SEATS ie. "E" ==================================== //
    public void emptySeats(Stage seatSelection,Button exit,Button used,Button available) {

        System.out.println(" ");
        System.out.println("=======================VIEW EMPTY SEATS=======================");

        used.setStyle("-fx-background-color: #b22a40"); // Styling guide links
        used.setDisable(true);
        available.setStyle("-fx-background-color: #2f76b2");
        available.setDisable(true);

        for (int i=1;i<=SEATING_CAPACITY;i++){  // Styling for used and empty seats
            button[i].setId("emptySeatsButtons");
            button[i].setStyle("-fx-background-color: #2f76b2");
        }

        //Initializing used buttons
        for (String s : seatList) {  //setting each item in seatlist array list to variable S
            // Styling and working for seats already booked
            String direction = cache[2].substring(1, 4);
            String seatNum = s.substring(0, 2);
            int start = Integer.parseInt(cache[2].substring(5, 7));  //getting values for checking values in array
            int end = Integer.parseInt(cache[2].substring(8, 10));
            int receivedStart = Integer.parseInt(s.substring(7, 9));
            int receivedEnd = Integer.parseInt(s.substring(10, 12));
            if (direction.compareTo("ctb") == 0) {  //checking inputs direction
                if ((s.contains(cache[0]))) {
                    if (!(((start <= receivedStart) && (end <= receivedStart)) || ((start >= receivedEnd) && (end >= receivedEnd)))) {
                        // validation of stops through array list id
                        button[Integer.parseInt(seatNum)].setStyle("-fx-background-color: #b24146");
                        button[Integer.parseInt(seatNum)].setDisable(true);
                    }
                }
            } else if (direction.compareTo("btc") == 0) {  //checking inputs direction
                if ((s.contains(cache[0]))) {
                    if (!(((start >= receivedStart) && (end >= receivedStart)) || ((start <= receivedEnd) && (end <= receivedEnd)))) {
                        // validation of stops through array list id
                        button[Integer.parseInt(seatNum)].setStyle("-fx-background-color: #b24146");
                        button[Integer.parseInt(seatNum)].setDisable(true);
                    }
                }
            }
        }

        //Exit button onClick
        exit.setOnAction(event -> {
            seatSelection.close();
            try {
                menu(); //calling back menu to sustain program- On press of exit button
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

    }

    // ===================================== METHOD FOR DELETING CUSTOMER ie. "D"==================================== //
    public void deleteCustomer() throws Exception {
        Scanner input=new Scanner(System.in);
        boolean found=false;
        System.out.println("Enter your name or ID to delete: ");
        String userInput = input.next().toLowerCase();  // Gets the input from the user for name
        for (int i = 0; i < seatList.size(); i++) {
            String recName= seatList.get(i).substring(24,seatList.get(i).length()-5);
            String recId= seatList.get(i).substring(seatList.get(i).length()-4);
            if ((recName.contains(userInput))||(recId.equals(userInput))) {
                System.out.print("Your name/ ID has been detected on the " + seatList.get(i).substring(13,23) + ", heading from ");
                if (seatList.get(i).substring(3, 6).equals("ctb")){
                    System.out.print("Colombo to Badulla on seat number ");
                }else{
                    System.out.print("Badulla to Colombo on seat number ");
                }
                System.out.print(seatList.get(i).substring(0,2)+" on ID ");
                System.out.println(recId);
                System.out.println("Are you sure to delete entry? (Yes/No)");
                String choice= input.next().toLowerCase();
                if (choice.equals("yes")){
                    seatList.remove(i); //removing the required data
                    System.out.println("Local Deletion Successful! ");
                }else{
                    System.out.println("Local Deletion UnSuccessful!- User terminate");
                }
                found = true;
            }
        }
        if (!found){
            System.out.println("Oops! Couldn't find that! Want to give it another try? ");
            System.out.println("Press <O> to try again, or any other key to move back to the main menu: ");
            String choice= input.next().toLowerCase();
            if (choice.equals("o")){
                deleteCustomer();
            }else{
                System.out.println("Process Exit. No changes to local.");
                menu(); //calling back menu to sustain program
            }
        }else{
            System.out.println("Process Exit. Local updated. Make sure to press upload the data.");
            menu();  //calling back menu to sustain program- On press of exit button
        }
    }

    // ====================================== METHOD FOR FIND CUSTOMER IE. "F" ====================================== //
    public void findCustomer() throws Exception {
        Scanner input=new Scanner(System.in);
        boolean found=false;
        System.out.println("Enter your name or ID to find: ");
        String userInput = input.next().toLowerCase();  // Gets the input from the user for name
        for (int i = 0; i < seatList.size(); i++) {
            String recName= seatList.get(i).substring(24,seatList.get(i).length()-5);
            String recId= seatList.get(i).substring(seatList.get(i).length()-4);
            if ((recName.contains(userInput))||(recId.equals(userInput))) {
                System.out.print("Your name/ ID has been detected on the " + seatList.get(i).substring(13,23) + ", heading from ");
                if (seatList.get(i).substring(3, 6).equals("ctb")){
                    System.out.print("Colombo to Badulla on seat number ");
                }else{
                    System.out.print("Badulla to Colombo on seat number ");
                }
                System.out.print(seatList.get(i).substring(0,2)+" on ID ");
                System.out.println(recId);
                found = true;
            }
        }
        if (!found){
            System.out.println("Oops! Couldn't find that! Want to give it another try? ");
            System.out.println("Press <O> to try again, or any other key to move back to the main menu: ");
            String choice= input.next().toLowerCase();
            if (choice.equals("o")){
                findCustomer();
            }else{
                System.out.println("Process Exit. No changes to local.");
                menu(); //calling back menu to sustain program
            }
        }else{
            System.out.println("Process Exit. No changes to local.");
            menu();  //calling back menu to sustain program- On press of exit button
        }
    }

    //=================================== CONNECTION WITH DATABASE FOR STORING ie. "S" ============================== //
    public void databaseStore() throws Exception {
        System.out.println("System: Initializing connection...");
        MongoClient client = MongoClients.create();
        MongoDatabase dataBase = client.getDatabase("BookingDB");
        MongoCollection<Document> baseCollection = dataBase.getCollection("bookCollection");
        baseCollection.drop();
        Document passenger=new Document("name",seatList);
        baseCollection.insertOne(passenger);
        System.out.println("System: Connection Successful");
        System.out.println("System: Store Successful");
        menu();  //calling back menu to sustain program- On press of exit button
    }

    //================================== CONNECTION WITH DATABASE FOR RETRIEVAL ie. "L" ============================= //
    public void databaseRetrieval() throws Exception {
        System.out.println("System: Initializing connection...");
        MongoClient client = MongoClients.create();
        MongoDatabase dataBase = client.getDatabase("BookingDB");
        MongoCollection<Document> baseCollection = dataBase.getCollection("bookCollection");
        Document tempHold = baseCollection.find() .first();
        Object seats = tempHold.get("name");
        seatList=(ArrayList<String>)seats;
        System.out.println("System: Connection Successful");
        System.out.println("System: Load Successful");
        LocalDate date= LocalDate.now();
        int counter=0;
        for (int i=seatList.size()-1;i>=0;i--){  //checking for old data and deleting them
            int finalI;
            finalI = i;
            String current = seatList.get(i).substring(13, 23);
            String strDate = date.toString();
            if ((current.compareTo(strDate)) < 0 ){
                seatList.remove(finalI);
                counter++;
            }
        }
        if (counter>0){
            System.out.println(counter+" Entries Expired. System Deleted");
        }
        if (seatList.size()>0) {
            String last = seatList.get(seatList.size() - 1);
            uniqueId = Integer.parseInt(last.substring(last.length() - 4));
        }
        System.out.println("System: Data Initiated");
        menu();  //calling back menu to sustain program- On press of exit button
    }

    //==================================== METHOD FOR SHOW SEATS IN ALPHA ORDER ie. "O" ============================= //
    public void sortSeats() throws Exception {
        if (seatList.size()==0){
            System.out.println("Oops! Nothing to Sort!");
        }else {
            int longest=0;
            //Uses the classical Bubble Sort
            String[] tempNames = new String[seatList.size()];
            String[] tempSeats = new String[seatList.size()];
            for (int count=0;count<seatList.size();count++){  // Initialing and adding the data to new array
                tempNames[count]=seatList.get(count).substring(24,seatList.get(count).length()-5);
                tempSeats[count]=seatList.get(count);
                if (tempNames[count].length()>longest){ longest=tempNames[count].length(); }  //Comparing sizes of the names to get longest
            }
            String nameCache;
            String seatCache;
            for (int numOne = 0; numOne < tempNames.length; numOne++) {  // Using classical bubble sort
                for (int numTwo = numOne + 1; numTwo < tempNames.length; numTwo++) {
                    // comparing adjacent strings
                    if (tempNames[numTwo].compareTo(tempNames[numOne])<0) {
                        nameCache = tempNames[numTwo];
                        seatCache = tempSeats[numTwo];
                        tempNames[numTwo] = tempNames[numOne];
                        tempSeats[numTwo] = tempSeats[numOne];
                        tempNames[numOne] = nameCache;
                        tempSeats[numOne] = seatCache;
                    }
                }
            }
            System.out.println("Data sorted successfully!");
            System.out.println(" ");
            System.out.print("   | Name");
            for (int i=0;i<=longest-4;i++){ System.out.print(" "); }
            System.out.println(" | Date       | Direction          | Start Station  | Finish Station  | Seat Number | Ticket ID |");
            System.out.print("   |-----");
            for (int i=0;i<=longest-4;i++){ System.out.print("-"); }
            System.out.println("-|------------|--------------------|----------------|-----------------|-------------|-----------|");
            for (int i = 0; i < seatList.size(); i++) {
                String name= tempNames[i];
                String seat= tempSeats[i];
                System.out.print("   | ");
                System.out.print(name.substring(0,1).toUpperCase()+name.substring(1));
                for (int nextI=0;nextI<=longest-name.length();nextI++){ System.out.print(" "); }
                System.out.print(" | "+seat.substring(13,23));
                if (seat.substring(3, 6).equals("ctb")){
                    System.out.print(" | Colombo to Badulla | ");
                }else{
                    System.out.print(" | Badulla to Colombo | ");
                }
                String stop=stops[Integer.parseInt(seat.substring(7,9))];
                System.out.print(stop);
                for (int nextI=0;nextI<=13-stop.length();nextI++){ System.out.print(" "); }
                System.out.print(" | "); //14
                stop=stops[Integer.parseInt(seat.substring(10,12))];
                System.out.print(stop);
                for (int nextI=0;nextI<=14-stop.length();nextI++){ System.out.print(" "); }
                System.out.print(" | ");
                System.out.print(seat.substring(0,2)+"          | ");
                System.out.println(seat.substring(seat.length()-4)+"      |");
            }
        }
        menu();  //calling back menu to sustain program- On press of exit button
    }

}

